<?php
/**
 * LogRequest
 *
 * Copyright 2016-2023 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package logrequest
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * class LogRequest
 */
class LogRequest extends \TreehillStudio\LogRequest\LogRequest
{
}
