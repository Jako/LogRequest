<?php
/**
 * Default Lexicon Entries for LogRequest
 *
 * @package logrequest
 * @subpackage lexicon
 */
$_lang['logrequest'] = 'LogRequest';
$_lang['logrequest.widget.count'] = 'Anzahl';
$_lang['logrequest.widget.date'] = 'Datum';
$_lang['logrequest.widget.log'] = 'LogRequest Log';
$_lang['logrequest.widget.log_desc'] = 'Dieses Widget zeigt die protokollierten Anfragen an.';
$_lang['logrequest.widget.rank'] = 'LogRequest Rang';
$_lang['logrequest.widget.rank_desc'] = 'Dieses Widget zeigt eine Rangliste der protokollierten Anfragen an.';
$_lang['logrequest.widget.value'] = 'Angefragter Wert';
