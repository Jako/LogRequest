<?php
/**
 * @package @package logrequest
 */
class LogRequestLog extends xPDOSimpleObject {}
?>