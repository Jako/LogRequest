<?php
/**
 * @package logrequest
 */
class LogRequestLog extends xPDOSimpleObject {}
?>