<?php
/**
 * Default Lexicon Entries for LogRequest
 *
 * @package logrequest
 * @subpackage lexicon
 */

$_lang['setting_logrequest.debug'] = 'Debug';
$_lang['setting_logrequest.debug_desc'] = 'Debug-Informationen im MODX Fehlerprotokoll ausgeben.';
$_lang['setting_logrequest.trigger'] = 'Anfrage-Trigger';
$_lang['setting_logrequest.trigger_desc'] = 'Anfrage-Trigger, der das Loggen auslöst.';
